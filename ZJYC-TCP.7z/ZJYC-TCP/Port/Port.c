






U16 ETH_Send(U8 * Addr,U16 Len)
{
    ;
}

U16 ETH_Recv(U8 * Addr)
{
    ;
}